# ROMarrNG PR #70 W505-W524 cross-review bundle

This portable bundle adjudicates 20 pinned source strings across 12 locales (240 cells) for head `e958b4fd0d9ddeac9333afc4c95da348b7f67cff` and tree `402026ba276ec4603d86d659766af836d839de55`.

The final ledger records every cell, the independent baseline decision, primary and blind dispositions, exact caller-context hashes and caller references, and the selected target hash. `selected-changes.jsonl` contains the 28 selected translations. `holds.jsonl` keeps 72 callerless cells text-free. The remaining 140 cells retain their current catalog values.

The independent baseline was written and checksummed before either candidate review output was opened. The full candidate-free input, both review outputs, and their verification scripts are included under `provenance/`. No repository or application files were changed.

Run `python3 verify_cross.py` from this directory to verify the candidate-free packet, sealed independent baseline, review packets, cell linkage, selected-target token safety, and package checksums. Reviewer confidence is moderate; no native-speaker approval or browser review was performed.
