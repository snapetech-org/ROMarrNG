#!/usr/bin/env python3
"""Verify the candidate-free ROMarrNG W505-W524 independent review seal."""
import collections, hashlib, json, re, subprocess, sys
from pathlib import Path
HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
INPUT=ROOT/'provenance'/'candidate-free-input'
PH=re.compile(r'\{[^{}]+\}')
TAG=re.compile(r'<[^>]+>')
NUM=re.compile(r'(?<![\w])\d+(?:[.,]\d+)?(?![\w])')
def need(v,m):
    if not v: raise SystemExit('FAIL: '+m)
def sha(b):
    if isinstance(b,str): b=b.encode('utf-8')
    return hashlib.sha256(b).hexdigest()
def canon(x): return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')
def j(p): return json.loads(p.read_text(encoding='utf-8'))
def jl(p): return [json.loads(s) for s in p.read_text(encoding='utf-8').splitlines() if s.strip()]
manifest=j(HERE/'manifest.json')
need((manifest['head'],manifest['tree'],manifest['window'])==('e958b4fd0d9ddeac9333afc4c95da348b7f67cff','402026ba276ec4603d86d659766af836d839de55','W505-W524'),'exact pin mismatch')
need(manifest['sealedBeforeReviewOutputsOpened'] is True,'independent baseline not marked sealed before outputs')
need((manifest['sourceCount'],manifest['localeCount'],manifest['cellCount'])==(20,12,240),'coverage metadata mismatch')
for item in manifest['files']:
    p=HERE/item['path']
    need(p.stat().st_size==item['bytes'] and sha(p.read_bytes())==item['sha256'],'sealed file hash mismatch: '+item['path'])
# The input packet's own portable verifier is the authority for candidate-free integrity.
r=subprocess.run([sys.executable,str(INPUT/'verify_input.py')],capture_output=True,text=True)
need(r.returncode==0 and '"result": "PASS"' in r.stdout,'candidate-free verifier failed: '+r.stdout+r.stderr)
source=jl(INPUT/'source-inventory-selection.jsonl')
contexts=jl(INPUT/'source-contexts.jsonl')
cells=jl(INPUT/'current-target-cells.jsonl')
ledger=jl(HERE/'per-cell-ledger.jsonl')
changes=jl(HERE/'selected-changes.jsonl')
holds=jl(HERE/'holds.jsonl')
need(len(source)==20 and len(contexts)==20 and len(cells)==240 and len(ledger)==240,'input/ledger row counts')
ctx={x['sourceId']:x for x in contexts}
by={(x['sourceId'],x['locale']):x for x in cells}
led={(x['sourceId'],x['locale']):x for x in ledger}
need(len(led)==240 and set(led)==set(by),'ledger coverage / uniqueness')
need(len(holds)==72 and len(changes)==8,'hold/change counts')
need(sum(x['decision']=='retain_current' for x in ledger)==160,'retained count')
need(sum(x['callerless'] for x in ledger)==72,'callerless count')
need(not any(any(k in x for k in ('source','currentTarget','selectedTarget','proposedTarget','target')) for x in holds),'hold output contains text')
need(not any(x['callerless'] is False and x['decision']=='hold_callerless' for x in ledger),'unexpected non-callerless hold')
change_by={(x['sourceId'],x['locale']):x for x in changes}
hold_by={(x['sourceId'],x['locale']):x for x in holds}
need(len(change_by)==8 and len(hold_by)==72,'selected change / hold uniqueness')
for k,row in led.items():
    c=by[k]; cx=ctx[k[0]]
    need(row['sourceSha256']==c['sourceSha256'] and row['currentTargetSha256']==c['currentTargetSha256'],'source/target hash drift')
    need(row['callerContextSha256']==cx['contextSha256'] and row['callerless']==cx['callerless'],'caller context mismatch')
    need(row['callerCount']==cx['exactMatchCount'],'caller count mismatch')
    need(row['selectedTargetSha256']==c['currentTargetSha256'] if row['decision'] in ('retain_current','hold_callerless') else True,'retained/hold target hash mismatch')
    if cx['callerless']:
        need(row['decision']=='hold_callerless' and k in hold_by and k not in change_by,'callerless disposition mismatch')
        need(not any(f in row for f in ('selectedTarget','currentTarget','source')),'callerless ledger contains text')
        h=hold_by[k]
        need(h['sourceSha256']==c['sourceSha256'] and h['currentTargetSha256']==c['currentTargetSha256'] and h['callerContextSha256']==cx['contextSha256'],'hold hashes mismatch')
    elif row['decision']=='select_independent_change':
        need(k in change_by,'change ledger entry missing')
        d=change_by[k]
        need(d['selectedTargetSha256']==row['selectedTargetSha256'] and sha(d['selectedTarget'])==row['selectedTargetSha256'],'selected target hash mismatch')
        need(d['callerContextSha256']==cx['contextSha256'],'selected change caller-context hash mismatch')
        target=d['selectedTarget']
        need(collections.Counter(PH.findall(c['source']))==collections.Counter(PH.findall(target)),'placeholder mismatch: '+str(k))
        need(collections.Counter(TAG.findall(c['source']))==collections.Counter(TAG.findall(target)),'markup mismatch: '+str(k))
        source_nums=collections.Counter(NUM.findall(c['source'])); target_nums=collections.Counter(NUM.findall(target))
        extras=list((target_nums-source_nums).elements())
        zero_equiv=bool(c.get('numericPresentationEquivalent')) and bool(c.get('sourceNumericWords')) and c['sourceNumericWords']==['Zero'] and not source_nums and extras==['0']
        need(not (source_nums-target_nums) and (not extras or zero_equiv),'numeric mismatch: '+str(k))
        need(all(term in target for term in c['sourceProtectedLiterals']),'protected literal mismatch: '+str(k))
    else:
        need(row['decision']=='retain_current' and k not in change_by and k not in hold_by,'invalid retained disposition')
# Ensure exactly the ledger's hold and change sets are represented.
need(set(hold_by)=={k for k,x in led.items() if x['decision']=='hold_callerless'},'hold file set mismatch')
need(set(change_by)=={k for k,x in led.items() if x['decision']=='select_independent_change'},'change file set mismatch')
print(json.dumps({'result':'PASS','head':manifest['head'],'tree':manifest['tree'],'cells':len(ledger),'changes':len(changes),'holds':len(holds),'retained':160,'candidateFreeVerifier':'PASS'},sort_keys=True))
