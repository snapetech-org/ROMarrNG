#!/usr/bin/env python3
"""Verify the portable ROMarrNG PR #70 W505-W524 cross-review bundle."""
import collections, hashlib, json, re, subprocess, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
INPUT=ROOT/'provenance'/'candidate-free-input'
PRIMARY=ROOT/'provenance'/'primary-run'/'primary'
PINPUT=ROOT/'provenance'/'primary-run'/'candidate-free'/'input'
BLIND=ROOT/'provenance'/'blind-review-output'
INDEPENDENT=ROOT/'independent-sealed'
HEAD='e958b4fd0d9ddeac9333afc4c95da348b7f67cff'
TREE='402026ba276ec4603d86d659766af836d839de55'
LOCALES=['ar','de','es','fr','hi','id','ja','ko','pt-BR','vi','zh-Hans','zh-Hant']
PH=re.compile(r'\{[^{}]+\}')
TAG=re.compile(r'<[^>]+>')
NUM=re.compile(r'(?<![\w])\d+(?:[.,]\d+)?(?![\w])')
def need(ok,msg):
    if not ok: raise SystemExit('FAIL: '+msg)
def sha(b):
    if isinstance(b,str): b=b.encode('utf-8')
    return hashlib.sha256(b).hexdigest()
def canon(x): return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')
def j(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def jl(p): return [json.loads(s) for s in Path(p).read_text(encoding='utf-8').splitlines() if s.strip()]
def run(cmd,label):
    r=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True)
    need(r.returncode==0,label+' failed: '+r.stdout+r.stderr)
    return r.stdout.strip()
# Verify the bundle manifest and its declared file inventory.
manifest=j(ROOT/'manifest.json')
need((manifest['head'],manifest['tree'],manifest['window'])==(HEAD,TREE,'W505-W524'),'bundle manifest pin')
need((manifest['sourceCount'],manifest['localeCount'],manifest['cellCount'])==(20,12,240),'bundle manifest scope')
manifest_files={x['path']:x for x in manifest['files']}
need(len(manifest_files)==len(manifest['files']),'duplicate manifest file path')
for name,item in manifest_files.items():
    pth=ROOT/name
    need(pth.is_file() and pth.stat().st_size==item['bytes'] and sha(pth.read_bytes())==item['sha256'],'manifest file mismatch: '+name)
# Verify the top-level bundle checksum list exactly covers every file except itself.
checks={}
for line in (ROOT/'CHECKSUMS.sha256').read_text(encoding='utf-8').splitlines():
    digest,name=line.split('  ',1)
    p=Path(name)
    need(name not in checks and not p.is_absolute() and '..' not in p.parts,'unsafe/duplicate bundle checksum path: '+name)
    full=ROOT/p
    need(full.is_file() and sha(full.read_bytes())==digest,'bundle checksum mismatch: '+name)
    checks[name]=digest
actual={p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file() and p != ROOT/'CHECKSUMS.sha256'}
need(set(checks)==actual,'bundle checksum coverage mismatch')
need(set(manifest_files)==actual-{'manifest.json'},'manifest file coverage mismatch')
# Re-run each included packet verifier. The primary copy has its candidate-free sibling in the expected layout.
input_result=run([sys.executable,str(INPUT/'verify_input.py')],'candidate-free verifier')
need('"result": "PASS"' in input_result,'candidate-free verifier result')
need(sha((INPUT/'manifest.json').read_bytes())==sha((PINPUT/'manifest.json').read_bytes()),'primary candidate-free copy manifest differs')
need(sha((INPUT/'SHA256SUMS.txt').read_bytes())==sha((PINPUT/'SHA256SUMS.txt').read_bytes()),'primary candidate-free copy checksum list differs')
primary_result=run([sys.executable,str(PRIMARY/'verify_primary.py')],'primary verifier')
need('"result": "PASS"' in primary_result,'primary verifier result')
blind_result=run([sys.executable,str(BLIND/'verify_packet.py')],'blind verifier')
need('"result": "PASS"' in blind_result,'blind verifier result')
independent_result=run([sys.executable,str(INDEPENDENT/'verify_independent.py')],'independent verifier')
need('"result": "PASS"' in independent_result,'independent verifier result')
# Exact task pin and input coverage.
im=j(INPUT/'manifest.json')
need((im['head'],im['tree'],im['window'],im['sourceCount'],im['localeCount'],im['cellCount'])==(HEAD,TREE,'W505-W524',20,12,240),'candidate-free exact pin/scope')
inputs=jl(INPUT/'current-target-cells.jsonl')
contexts=jl(INPUT/'source-contexts.jsonl')
ind_ledger=jl(INDEPENDENT/'per-cell-ledger.jsonl')
ind_changes=jl(INDEPENDENT/'selected-changes.jsonl')
p_ledger=jl(PRIMARY/'primary-ledger.jsonl')
p_proposals=jl(PRIMARY/'primary-proposals.jsonl')
b_cells=jl(BLIND/'review-cells.jsonl')
ledger=jl(ROOT/'per-cell-ledger.jsonl')
selected=jl(ROOT/'selected-changes.jsonl')
holds=jl(ROOT/'holds.jsonl')
summary=j(ROOT/'summary.json')
def by_key(rows): return {(x['sourceId'],x['locale']):x for x in rows}
input_by=by_key(inputs); ind_by=by_key(ind_ledger); p_by=by_key(p_ledger); pp_by=by_key(p_proposals); b_by=by_key(b_cells); cross_by=by_key(ledger); selected_by=by_key(selected); hold_by=by_key(holds)
ctx={x['sourceId']:x for x in contexts}
need(len(inputs)==240 and len(contexts)==20 and len(ind_ledger)==240 and len(p_ledger)==240 and len(p_proposals)==21 and len(b_cells)==240,'source packet coverage')
need(len(ledger)==240 and len(cross_by)==240 and set(cross_by)==set(input_by),'cross ledger coverage/uniqueness')
need(len(selected)==28 and len(selected_by)==28 and len(holds)==72 and len(hold_by)==72,'final selected/hold counts')
need(len(ind_changes)==8,'independent selected-change count')
need(len(pp_by)==21,'primary proposal uniqueness')
need(sum(x['callerless'] for x in contexts)==6,'callerless source count')
need(not any(any(k in x for k in ('source','currentTarget','selectedTarget','proposedTarget','target')) for x in holds),'cross hold output contains translation/source text')
# Candidate input provenance binds to the exact source and caller evidence; every proposal is checked against that context.
for k,c in input_by.items():
    s=ctx[k[0]]; x=cross_by[k]; ind=ind_by[k]; pr=p_by[k]; br=b_by[k]
    need(x['sourceSha256']==c['sourceSha256'] and x['currentTargetSha256']==c['currentTargetSha256'],'source/current-target hash linkage: '+str(k))
    need(x['callerContextSha256']==s['contextSha256'] and ind['callerContextSha256']==s['contextSha256'],'caller context linkage: '+str(k))
    need(x['callerless']==s['callerless'] and x['callerCount']==s['exactMatchCount'],'caller count/status linkage: '+str(k))
    need(x['independentDecision']==ind['decision'] and x['independentSelectedTargetSha256']==ind['selectedTargetSha256'],'independent decision linkage: '+str(k))
    need(x['primaryDisposition']==pr['disposition'] and x['primaryRecordSha256']==sha(canon(pr)),'primary row linkage: '+str(k))
    need(x['blindDisposition']==br['disposition'] and x['blindCellRecordSha256']==sha(canon(br)),'blind row linkage: '+str(k))
    pprop=pp_by.get(k)
    need(x['primaryProposalRecordSha256']==(sha(canon(pprop)) if pprop else None),'primary proposal linkage: '+str(k))
    need(x['primaryProposedTargetSha256']==(pprop['proposedTargetSha256'] if pprop else None),'primary target hash linkage: '+str(k))
    need(x['blindProposedTargetSha256']==br.get('proposedTargetSha256'),'blind target hash linkage: '+str(k))
    caller_refs=[] if s['callerless'] else [{'path':r['path'],'line':r['line'],'matchKind':r['matchKind'],'lineSha256':r['lineSha256'],'excerptSha256':r['excerptSha256'],'fileSha256':r['fileSha256'],'gitBlob':r['gitBlob']} for r in s['callers']]
    need(x['callerEvidence']==caller_refs,'caller evidence references differ: '+str(k))
    if s['callerless']:
        need(x['finalDisposition']=='hold_callerless' and x['selectedTargetSource']=='none','callerless final disposition: '+str(k))
        need(not any(f in x for f in ('source','currentTarget','selectedTarget','proposedTarget','target')),'callerless per-cell row contains text: '+str(k))
        need(pr['disposition']=='hold' and br['disposition']=='hold','callerless review outputs: '+str(k))
        need(k in hold_by and k not in selected_by,'callerless hold file coverage: '+str(k))
        h=hold_by[k]
        need(h['sourceSha256']==c['sourceSha256'] and h['currentTargetSha256']==c['currentTargetSha256'] and h['callerContextSha256']==s['contextSha256'],'hold source/target/context hashes: '+str(k))
        continue
    need(x['finalDisposition'] in ('retain_current','select_change'),'invalid final disposition: '+str(k))
    need(pr['callerContextSha256']==s['contextSha256'] and br['callerContextSha256']==s['contextSha256'],'candidate context mismatch: '+str(k))
    need(pr['currentTargetSha256']==c['currentTargetSha256'] and br['currentTargetSha256']==c['currentTargetSha256'],'candidate current target mismatch: '+str(k))
    if x['finalDisposition']=='retain_current':
        need(x['selectedTargetSource']=='current' and x['selectedTargetSha256']==c['currentTargetSha256'] and k not in selected_by,'retained current linkage: '+str(k))
    else:
        need(k in selected_by,'selected change missing: '+str(k))
        d=selected_by[k]
        need(d['selectedTargetSha256']==x['selectedTargetSha256'] and sha(d['selectedTarget'])==x['selectedTargetSha256'],'selected target hash linkage: '+str(k))
        need(d['callerContextSha256']==s['contextSha256'] and d['currentTargetSha256']==c['currentTargetSha256'],'selected target caller/current linkage: '+str(k))
        if x['selectedTargetSource'] in ('primary','primary+blind'):
            need(k in pp_by and pp_by[k]['proposedTargetSha256']==x['selectedTargetSha256'],'primary selection is not its proposal: '+str(k))
        if x['selectedTargetSource']=='primary+blind':
            need(br['disposition']=='revise' and br['proposedTargetSha256']==x['selectedTargetSha256'],'reviewer agreement mismatch: '+str(k))
        if x['selectedTargetSource']=='blind':
            need(br['disposition']=='revise' and br['proposedTargetSha256']==x['selectedTargetSha256'],'blind selection is not its proposal: '+str(k))
        if x['selectedTargetSource']=='independent':
            need(ind['decision']=='select_independent_change' and ind['selectedTargetSha256']==x['selectedTargetSha256'],'independent-only selected target mismatch: '+str(k))
        # Check placeholder, markup, numeric, and protected tokens on every selected change.
        target=d['selectedTarget']
        need(collections.Counter(PH.findall(c['source']))==collections.Counter(PH.findall(target)),'placeholder mismatch: '+str(k))
        need(collections.Counter(TAG.findall(c['source']))==collections.Counter(TAG.findall(target)),'markup mismatch: '+str(k))
        src_nums=collections.Counter(c['sourceNumericTokens']); dst_nums=collections.Counter(NUM.findall(target))
        extras=list((dst_nums-src_nums).elements())
        zero_equiv=bool(c.get('numericPresentationEquivalent')) and c.get('sourceNumericWords')==['Zero'] and not src_nums and extras==['0']
        need(not (src_nums-dst_nums) and (not extras or zero_equiv),'numeric mismatch: '+str(k))
        need(all(t in target for t in c['sourceProtectedLiterals']),'protected literal mismatch: '+str(k))
# Summaries must exactly report the final ledger.
counts=collections.Counter(x['finalDisposition'] for x in ledger)
need(counts=={'hold_callerless':72,'select_change':28,'retain_current':140},'final disposition totals')
need(summary['finalCounts']=={'hold_callerless':72,'select_change':28,'retain_current':140},'summary count mismatch')
need(summary['head']==HEAD and summary['tree']==TREE and summary['cellCount']==240,'summary pin/scope')
need(summary['independentDecisionsRevisedAfterFullContextCrossReview']==2,'independent cross-review reconciliation count')
need(summary['primary']['candidateProposals']==21 and summary['primary']['selectedProposedTargets']==21,'primary proposal summary')
need(summary['blind']['revisions']==11 and summary['blind']['selectedExactProposedTargets']==10 and summary['blind']['alternateTargetSuperseded']==1,'blind proposal summary')
need(summary['tokenMismatchesInFinalSelectedChanges']=={'placeholder':0,'markup':0,'numeric':0,'protectedLiteral':0},'final token mismatch summary')
print(json.dumps({'result':'PASS','head':HEAD,'tree':TREE,'cells':len(ledger),'selectedChanges':len(selected),'holds':len(holds),'retained':140,'primary':'PASS','blind':'PASS','independentBaseline':'PASS','candidateFree':'PASS','tokenMismatches':summary['tokenMismatchesInFinalSelectedChanges']},sort_keys=True))
