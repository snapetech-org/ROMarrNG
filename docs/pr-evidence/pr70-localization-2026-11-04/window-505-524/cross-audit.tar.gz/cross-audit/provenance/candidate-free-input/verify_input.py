#!/usr/bin/env python3
"""Portable integrity verifier for ROMarrNG PR #70 W505-W524 candidate-free input."""
import collections, hashlib, json, re
from pathlib import Path

HERE=Path(__file__).resolve().parent
HEAD='e958b4fd0d9ddeac9333afc4c95da348b7f67cff'
TREE='402026ba276ec4603d86d659766af836d839de55'
LOCALES=['ar','de','es','fr','hi','id','ja','ko','pt-BR','vi','zh-Hans','zh-Hant']
FORBIDDEN={'proposedTarget','proposedTargetSha256','selectedTarget','selectedTargetSha256','disposition','rationale','primaryDisposition','blindDisposition','decision'}
PH=re.compile(r'\{[^{}]+\}')
TAG=re.compile(r'<[^>]+>')
NUM=re.compile(r'(?<![\w])\d+(?:[.,]\d+)?(?![\w])')
def fail(m): raise SystemExit('FAIL: '+m)
def need(v,m):
    if not v: fail(m)
def sha(b):
    if isinstance(b,str): b=b.encode()
    return hashlib.sha256(b).hexdigest()
def canon(x): return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def j(n): return json.loads((HERE/n).read_text(encoding='utf-8'))
def jl(n): return [json.loads(x) for x in (HERE/n).read_text(encoding='utf-8').splitlines() if x.strip()]
def check_safe(x,where='input'):
    if isinstance(x,dict):
        bad=FORBIDDEN.intersection(x)
        need(not bad,f'candidate decisions/proposals present in {where}: {sorted(bad)}')
        for k,v in x.items(): check_safe(v,where+'.'+k)
    elif isinstance(x,list):
        for i,v in enumerate(x): check_safe(v,f'{where}[{i}]')

manifest=j('manifest.json')
need(manifest['candidateFree'] is True and manifest['proposedTargetsIncluded'] is False and manifest['reviewDecisionsIncluded'] is False,'candidate-free manifest flags')
need((manifest['head'],manifest['tree'],manifest['window'])==(HEAD,TREE,'W505-W524'),'exact pin/window mismatch')
need(manifest['sourceCount']==20 and manifest['localeCount']==12 and manifest['cellCount']==240,'manifest coverage mismatch')
need(manifest['locales']==LOCALES,'locale order mismatch')
# Verify each listed packet file and ensure the checksum list exactly covers input files.
checks={}
for raw in (HERE/'SHA256SUMS.txt').read_text().splitlines():
    h,n=raw.split('  ',1); checks[n]=h
    need(sha((HERE/n).read_bytes())==h,'input checksum mismatch: '+n)
actual={p.name for p in HERE.iterdir() if p.is_file() and p.name!='SHA256SUMS.txt'}
need(set(checks)==actual,'checksum file coverage mismatch')
for row in manifest['files']:
    b=(HERE/row['path']).read_bytes()
    need(len(b)==row['bytes'] and sha(b)==row['sha256'],'manifest file mismatch: '+row['path'])
for n in actual:
    check_safe(jl(n) if n.endswith('.jsonl') else j(n),n) if n.endswith('.jsonl') or n.endswith('.json') else None

inventory=jl('catalog-source-inventory.jsonl')
selected=jl('source-inventory-selection.jsonl')
contexts=jl('source-contexts.jsonl')
cells=jl('current-target-cells.jsonl')
prior=jl('prior-selection-reattestation.jsonl')
holds=jl('prior-hold-reattestation.jsonl')
need(len(inventory)==1836,'full catalog inventory count')
need([x['catalogZeroBasedIndex'] for x in inventory]==list(range(1836)),'catalog index order')
ids=[x['sourceId'] for x in inventory]
need(sha('\n'.join(ids)+'\n')==manifest['catalogKeyOrderSha256'],'catalog insertion order hash')
need(all(sha(x['source'])==x['sourceSha256'] for x in inventory),'source hash mismatch')
need(len(selected)==20 and [x['catalogZeroBasedIndex'] for x in selected]==list(range(505,525)),'selected source positions')
need(len({x['sourceId'] for x in selected})==20,'selected source uniqueness')
need([x['sourceId'] for x in selected]==ids[505:525],'selected source IDs differ from inventory positions')
need(len(contexts)==20 and {x['sourceId'] for x in contexts}=={x['sourceId'] for x in selected},'caller context coverage')
for c in contexts:
    base={k:v for k,v in c.items() if k!='contextSha256'}
    need(sha(canon(base))==c['contextSha256'],'caller context hash mismatch')
need(len(cells)==240 and len({(x['sourceId'],x['locale']) for x in cells})==240,'current target cell count/uniqueness')
ctx={x['sourceId']:x for x in contexts}
by={(x['sourceId'],x['locale']):x for x in cells}
need(set(by)=={(s['sourceId'],l) for s in selected for l in LOCALES},'current target coverage')
for c in cells:
    need(c['locale'] in LOCALES and c['sourceId'] in ctx,'cell locale/context mismatch')
    need(c['callerContextSha256']==ctx[c['sourceId']]['contextSha256'],'cell context hash mismatch')
    need(sha(c['currentTarget'])==c['currentTargetSha256'],'current target hash mismatch')
    need(c['containsCandidate'] is False,'candidate flag present')
    need(collections.Counter(PH.findall(c['source']))==collections.Counter(c['currentPlaceholderTokens']),'placeholder evidence mismatch')
    need(collections.Counter(TAG.findall(c['source']))==collections.Counter(c['currentMarkupTags']),'markup evidence mismatch')
    need(collections.Counter(NUM.findall(c['source']))==collections.Counter(c['sourceNumericTokens']),'numeric source evidence mismatch')
    need(collections.Counter(NUM.findall(c['currentTarget']))==collections.Counter(c['currentNumericTokens']),'numeric target evidence mismatch')
    need(collections.Counter(PH.findall(c['source']))==collections.Counter(PH.findall(c['currentTarget'])),'placeholder mismatch')
    need(collections.Counter(TAG.findall(c['source']))==collections.Counter(TAG.findall(c['currentTarget'])),'markup mismatch')
    source_nums=collections.Counter(c['sourceNumericTokens'])
    target_nums=collections.Counter(c['currentNumericTokens'])
    extras=list((target_nums-source_nums).elements())
    zero_equiv=bool(c.get('numericPresentationEquivalent')) and bool(c.get('sourceNumericWords')) and c['sourceNumericWords']==['Zero'] and not source_nums and extras==['0']
    need(not (source_nums-target_nums) and (not extras or zero_equiv),'numeric token mismatch')
    need(c['numericTokensPreserved'] is True,'numeric preservation flag mismatch')
    need(all(term in c['currentTarget'] for term in c['sourceProtectedLiterals']),'protected literal missing')
    need(c['protectedLiteralsPreserved'] is True,'protected literal evidence mismatch')
need(len(prior)==120 and len({x['sourceId'] for x in prior})==120,'prior selection count/uniqueness')
need(all(x['selectionPositionMatches'] and x['sourceHashMatches'] for x in prior),'prior selection reattestation failure')
need(len(holds)==468 and len({(x['sourceId'],x['locale']) for x in holds})==468,'prior hold count/uniqueness')
need(all(x['targetUnchanged'] and x['selectionPositionMatches'] and x['sourceMatchesCurrentCatalog'] for x in holds),'prior hold reattestation failure')
need(not any(any(k in x for k in ('source','currentTarget','target','proposedTarget','selectedTarget')) for x in holds),'hold file contains text')
continuity=j('continuity-reattestation.json')
need(continuity['result']=='PASS' and continuity['currentHead']==HEAD and continuity['currentTree']==TREE,'W485 continuity attestation')
need(continuity['priorSelectedSourceCount']==120 and continuity['priorSelectedSourceCountUnchanged'] is True and continuity['priorHoldCellCount']==468 and continuity['priorHoldChangedCellCount']==0,'W485 continuity counts')
pins=j('catalog-file-pins.json')
need(pins['commit']==HEAD and pins['tree']==TREE and pins['catalogKeyOrderSha256']==manifest['catalogKeyOrderSha256'],'current source manifest pin')
need(pins['catalogMessageCount']==1836 and pins['activeUniqueSourceIds']==479,'catalog/registry counts')
att=j('PR-attestation-before.json')
need(att['result']=='PASS' and att['state']=='OPEN' and att['draft'] is True and att['head']==HEAD and att['tree']==TREE and att['branchRefOid']==HEAD,'live PR attestation')
mismatch=j('current-target-token-mismatches.json')
need(mismatch=={'placeholder':0,'markup':0,'numeric':0,'numericPresentationDifferences':7,'protectedLiteral':0,'missingTarget':0},'token mismatch summary')
print(json.dumps({'result':'PASS','head':HEAD,'tree':TREE,'sources':len(selected),'cells':len(cells),'locales':len(LOCALES),'priorSelectedSourceIds':len(prior),'priorHoldCells':len(holds),'callerlessSources':sum(x['callerless'] for x in contexts),'tokenMismatches':mismatch},sort_keys=True))

