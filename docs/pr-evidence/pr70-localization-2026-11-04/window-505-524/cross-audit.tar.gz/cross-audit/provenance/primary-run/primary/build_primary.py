#!/usr/bin/env python3
"""Build the primary W505-W524 semantic review from its candidate-free packet."""
import collections, hashlib, json, re, subprocess
from pathlib import Path
from datetime import datetime, timezone

OUT=Path(__file__).resolve().parent
INPUT=OUT.parent/'candidate-free'/'input'
HEAD='e958b4fd0d9ddeac9333afc4c95da348b7f67cff'
TREE='402026ba276ec4603d86d659766af836d839de55'
PH=re.compile(r'\{[^{}]+\}')
TAG=re.compile(r'<[^>]+>')
NUM=re.compile(r'(?<![\w])\d+(?:[.,]\d+)?(?![\w])')
PROPOSALS={
 'ui.history-events.752cc7542a':{
  'hi':('correction','इतिहास लॉग की घटनाएँ','The caller displays a count of application history events; the current phrase reads as historical events.'),
  'id':('correction','Peristiwa dalam riwayat','The caller displays a count of application history events; sejarah suggests historical events rather than the app history log.'),
  'vi':('correction','Sự kiện trong nhật ký','The caller displays a count of application history events; the current phrase can read as historical events.'),
  'zh-Hans':('correction','历史记录中的事件','The caller displays a count of application history events; 历史事件 reads as events from history.'),
  'zh-Hant':('correction','歷史記錄中的事件','The caller displays a count of application history events; 歷史事件 reads as events from history.')
 },
 'ui.host.4a823118b9':{
  'pt-BR':('refinement','Host','This is a technical host/hostname field also reused in host status and protocol contexts; the stray full stop is inconsistent with the label.')
 },
 'ui.how-platforms-play-here.cd011072c1':{
  'ar':('refinement','كيفية تشغيل الألعاب على المنصات هنا','The caller summarizes how games run on each platform (in-browser, server-streamed, or download-only); the current wording says only how platforms work.'),
  'de':('refinement','Wie sich Spiele auf den Plattformen hier spielen lassen','The caller summarizes game play modes by platform; the current wording says only how platforms function.'),
  'es':('refinement','Cómo se pueden jugar aquí los juegos en cada plataforma','The caller summarizes game play modes by platform; the current wording says only how platforms work.'),
  'fr':('refinement','Comment jouer sur chaque plateforme ici','The caller summarizes game play modes by platform; the current wording says only how platforms function.'),
  'hi':('refinement','यहाँ हर प्लेटफ़ॉर्म पर गेम कैसे खेले जाते हैं','The caller summarizes game play modes by platform; the current wording says only how platforms work.'),
  'id':('refinement','Cara bermain game di tiap platform di sini','The caller summarizes game play modes by platform; the current wording says only how platforms work.'),
  'ja':('refinement','各プラットフォームでのゲームのプレイ方法','The caller summarizes game play modes by platform; the current wording says only how platforms operate.'),
  'ko':('refinement','여기서 플랫폼별 게임 플레이 방식','The caller summarizes game play modes by platform; the current wording says only how platforms operate.'),
  'pt-BR':('refinement','Como jogar em cada plataforma aqui','The caller summarizes game play modes by platform; the current wording says only how platforms function.'),
  'zh-Hans':('refinement','各个平台在此处的游戏玩法','The caller summarizes game play modes by platform; the current wording says only how platforms operate.'),
  'zh-Hant':('refinement','各平台在此處的遊戲玩法','The caller summarizes game play modes by platform; the current wording says only how platforms operate.')
 },
 'ui.i-have-an-invitation.ad676188ce':{
  'es':('refinement','Tengo una invitación','This is an onboarding button label; omit sentence punctuation on the short action choice.'),
  'fr':('refinement',"J'ai une invitation",'This is an onboarding button label; omit sentence punctuation on the short action choice.'),
  'ko':('correction','초대장이 있습니다','This is an onboarding choice to redeem an invitation; the current Korean phrase is ungrammatical.'),
  'pt-BR':('refinement','Tenho um convite','This is an onboarding button label; omit sentence punctuation on the short action choice.')
 }
}
HOLD_SOURCE_IDS={
 'ui.help.b79cac926e',
 'ui.home.3a78695388',
 'ui.how-long-a-finished-item-must-sit-un.d33bd87dee',
 'ui.how-long-a-finished-item-must-sit-un.fbce787fed',
 'ui.how-often-the-scheduled-jobs-run-zer.2a23bb5fe4',
 'ui.iso9660-with-a-playstation-volume-id.f0013644e4'
}
RATIONAL={'ui.hidden-gems.0650c15c81':'This is a catalog category for worthwhile, lesser-known games; the target preserves that metaphor.','ui.hide-owned.1fc90fc8dc':'This is a catalog filter checkbox; the target expresses hiding games already owned.','ui.highest-rated.35d17e3fb4':'This is the rating sort option in the catalog filter; the target preserves the superlative sort meaning.','ui.history.0e76960093':'This is a navigation item and page title for the app activity history; the target preserves the route label.','ui.history-events.752cc7542a':'This is a stats label for the number of app history events; the target conveys the event-history sense.','ui.host.4a823118b9':'This technical label is reused for a host field, a host header, and a visible host statistic; the target is understandable as the machine/address host.','ui.how-platforms-play-here.cd011072c1':'The target should describe how games are playable on each platform in the app.','ui.hub.d87c9ca31f':'This is a navigation group containing Plugins and Friends; the target conveys a central hub/space.','ui.i-already-have-roms.3e38d0345c':'This is an onboarding route choice; ROMs is preserved as the established file-format term.','ui.i-have-an-invitation.ad676188ce':'This is an onboarding choice to continue by redeeming an invitation.','ui.igdb-catalog-is-not-configured.6deb64d59f':'This is an API error returned when IGDB catalog configuration is missing; the product acronym is preserved.','ui.igdb-catalog-request-failed.47ac4d494b':'This is an API error returned when an IGDB catalog request fails; the product acronym and failure state are preserved.','ui.igdb-covers-genres-and-ratings.6035ecaefc':'This is a source-selection button naming the IGDB catalog and its cover, genre, and rating metadata.','ui.identify.4786cd5110':'This is a button that starts a metadata lookup to identify a ROM file.'}
def sha(x):
    if isinstance(x,str): x=x.encode()
    return hashlib.sha256(x).hexdigest()
def canon(x): return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def jl(p): return [json.loads(s) for s in Path(p).read_text(encoding='utf-8').splitlines() if s.strip()]
def dump(p,o): Path(p).write_text(json.dumps(o,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
def lines(p,rows): Path(p).write_text(''.join(json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':'))+'\n' for x in rows),encoding='utf-8')

# Always validate the candidate-free boundary first.
subprocess.run(['python3',str(INPUT/'verify_input.py')],check=True,stdout=subprocess.DEVNULL)
cells=jl(INPUT/'current-target-cells.jsonl')
ctx={x['sourceId']:x for x in jl(INPUT/'source-contexts.jsonl')}
selected={x['sourceId']:x for x in jl(INPUT/'source-inventory-selection.jsonl')}
expected_keys={(s,loc) for s in selected for loc in json.loads((INPUT/'manifest.json').read_text())['locales']}
if len(cells)!=240 or {(x['sourceId'],x['locale']) for x in cells}!=expected_keys: raise SystemExit('FAIL: input cell coverage')
now=datetime.now(timezone.utc).isoformat(timespec='seconds')
ledger=[]; proposals=[]; holds=[]
for c in cells:
    sid,loc=c['sourceId'],c['locale']; context=ctx[sid]
    base={'window':'W505-W524','position':c['catalogZeroBasedIndex'],'catalogZeroBasedIndex':c['catalogZeroBasedIndex'],'catalogOneBasedPosition':c['catalogZeroBasedIndex']+1,'sourceId':sid,'sourceSha256':c['sourceSha256'],'locale':loc,'catalogTranslationHash':c['catalogTranslationHash'],'currentTargetSha256':c['currentTargetSha256'],'callerContextSha256':c['callerContextSha256'],'callerRefs':c['callerRefs'],'placeholderChecks':{'source':c['sourcePlaceholderTokens'],'current':c['currentPlaceholderTokens'],'preserved':c['placeholderMultisetMatches']},'markupChecks':{'source':c['sourceMarkupTags'],'current':c['currentMarkupTags'],'preserved':c['markupMatches']},'numericChecks':{'source':c['sourceNumericTokens'],'sourceWords':c['sourceNumericWords'],'current':c['currentNumericTokens'],'preserved':c['numericTokensPreserved'],'presentationEquivalent':c['numericPresentationEquivalent']},'protectedLiteralChecks':{'source':c['sourceProtectedLiterals'],'current':c['currentProtectedLiterals'],'missing':c['missingProtectedLiterals'],'preserved':c['protectedLiteralsPreserved']},'reviewedAtUtc':now,'nativeSpeakerApproval':False,'reviewConfidence':'moderate'}
    if sid in HOLD_SOURCE_IDS:
        if not context['callerless']: raise SystemExit('FAIL: hold source unexpectedly has a caller')
        row={**base,'disposition':'hold','callerContextAvailable':False,'callerlessReason':'The exact-head candidate-free search found no source literal or source-ID caller in tracked production code; the UI role cannot be confirmed from the available context. No translation decision is made.'}
        holds.append({k:row[k] for k in ('window','position','sourceId','sourceSha256','locale','currentTargetSha256','callerContextSha256','disposition','callerlessReason')})
        ledger.append(row)
        continue
    if context['callerless']: raise SystemExit('FAIL: non-hold source lacks caller context')
    proposal=PROPOSALS.get(sid,{}).get(loc)
    if proposal:
        kind,target,reason=proposal
        tokens=lambda s:(collections.Counter(PH.findall(s)),collections.Counter(TAG.findall(s)),collections.Counter(NUM.findall(s)),[x for x in c['sourceProtectedLiterals'] if x not in s])
        a=tokens(c['source']); b=tokens(target)
        if a[0]!=b[0] or a[1]!=b[1] or a[2]!=b[2] or b[3]: raise SystemExit(f'FAIL: proposal token/literal mismatch {sid}/{loc}')
        disposition=kind
        row={**base,'source':c['source'],'currentTarget':c['currentTarget'],'proposedTarget':target,'proposedTargetSha256':sha(target),'disposition':disposition,'issueClass':{'correction':'semantic-or-grammar','refinement':'caller-context-precision'}[kind],'reviewedContext':RATIONAL[sid],'rationale':reason,'proposalTokenChecks':{'placeholdersPreserved':True,'markupPreserved':True,'numericTokensPreserved':True,'protectedLiteralsPreserved':True}}
        proposals.append({k:row[k] for k in ('window','position','sourceId','sourceSha256','locale','currentTargetSha256','currentTarget','proposedTarget','proposedTargetSha256','disposition','issueClass','rationale','callerContextSha256')})
    else:
        row={**base,'source':c['source'],'currentTarget':c['currentTarget'],'disposition':'accept-current','reviewedContext':RATIONAL[sid],'rationale':RATIONAL[sid]}
    ledger.append(row)
if len(ledger)!=240 or len(holds)!=72 or len(proposals)!=21: raise SystemExit('FAIL: expected dispositions not met')
counts=collections.Counter(x['disposition'] for x in ledger)
if counts!={'accept-current':147,'correction':6,'refinement':15,'hold':72}: raise SystemExit(f'FAIL: unexpected disposition counts {dict(counts)}')
locale_counts={}
for loc in json.loads((INPUT/'manifest.json').read_text())['locales']:
    locale_counts[loc]=dict(collections.Counter(x['disposition'] for x in ledger if x['locale']==loc))
summary={'artifact':'ROMarrNG PR #70 W505-W524 primary semantic review','reviewerRole':'primary semantic reviewer using candidate-free input only','repository':'snapetech-org/ROMarrNG','pullRequest':70,'branch':'task/localization-translation-review-20261030','head':'e958b4fd0d9ddeac9333afc4c95da348b7f67cff','tree':'402026ba276ec4603d86d659766af836d839de55','candidateFreeInputPath':'../candidate-free/input','candidateFreeInputManifestSha256':sha((INPUT/'manifest.json').read_bytes()),'candidateFreeInputChecksumListSha256':sha((INPUT/'SHA256SUMS.txt').read_bytes()),'candidateFreeInputVerified':True,'primaryProposalsReadBeforeReview':False,'sourceCount':20,'localeCount':12,'cellCount':240,'dispositions':dict(counts),'proposedCellCount':len(proposals),'newHolds':len(holds),'holdPositions':sorted({x['position'] for x in holds}),'holdFindings':{str(p):'No exact source literal or source-ID caller was found in the exact-head production search; keep all 12 locale cells held.' for p in sorted({x['position'] for x in holds})},'priorSelectedSourceCount':120,'priorHoldCellCount':468,'priorSelectionsUnchanged':True,'priorHoldTargetsUnchanged':True,'priorHoldChangedCells':0,'placeholderMismatchesInSelectedTargets':0,'markupMismatchesInSelectedTargets':0,'numericMismatchesInSelectedTargets':0,'numericPresentationEquivalences':7,'protectedLiteralMismatchesInSelectedTargets':0,'localeDispositionCounts':locale_counts,'nativeSpeakerApproval':False,'browserReviewClaimed':False,'reviewConfidence':'moderate','sealedAtUtc':now}
lines(OUT/'primary-ledger.jsonl',ledger)
lines(OUT/'primary-proposals.jsonl',proposals)
lines(OUT/'primary-holds.jsonl',holds)
dump(OUT/'summary.json',summary)
dump(OUT/'provenance.json',{'artifact':'ROMarrNG W505-W524 primary review provenance','candidateFreeInputManifestSha256':summary['candidateFreeInputManifestSha256'],'candidateFreeInputChecksumListSha256':summary['candidateFreeInputChecksumListSha256'],'candidateFreeVerifier':'PASS','reviewInputs':['candidate-free/input/current-target-cells.jsonl','candidate-free/input/source-contexts.jsonl','candidate-free/input/source-inventory-selection.jsonl','candidate-free/input/continuity-reattestation.json'],'reviewInputsWereCandidateFree':True,'priorBlindOrCrossReviewContentConsulted':False,'reviewedHead':summary['head'],'reviewedTree':summary['tree'],'nativeSpeakerApproval':False,'browserReviewClaimed':False})
(OUT/'README.md').write_text(f"""# ROMarrNG PR #70 W505-W524 primary review

- Pin: {summary['head']} / tree {summary['tree']}; PR remains OPEN/DRAFT.
- Scope: 20 source messages × 12 locales = 240 cells.
- Dispositions: {counts['accept-current']} accepted, {counts['correction']} corrections, {counts['refinement']} refinements, {counts['hold']} text-free holds.
- Holds are the 12 locale cells for each callerless source at catalog positions 505, 511, 513, 514, 515, and 523. Their ledgers contain hashes and IDs only, with no source or target text.
- Primary review used only the candidate-free packet. No blind or cross-review output was consulted. No native-speaker or browser review is claimed.
- Run python3 verify_primary.py from this directory.
""",encoding='utf-8')
print(json.dumps({'result':'PRIMARY_BUILT','cells':len(ledger),'counts':dict(counts),'proposals':len(proposals),'holds':len(holds),'holdPositions':sorted({x['position'] for x in holds})},ensure_ascii=False,indent=2))

