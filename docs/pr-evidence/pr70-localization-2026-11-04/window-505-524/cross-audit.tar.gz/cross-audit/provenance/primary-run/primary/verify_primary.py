#!/usr/bin/env python3
"""Portable semantic and integrity verifier for the W505-W524 primary review."""
import collections, hashlib, json, re, subprocess
from pathlib import Path

HERE=Path(__file__).resolve().parent
INPUT=HERE.parent/'candidate-free'/'input'
HEAD='e958b4fd0d9ddeac9333afc4c95da348b7f67cff'
TREE='402026ba276ec4603d86d659766af836d839de55'
LOCALES=['ar','de','es','fr','hi','id','ja','ko','pt-BR','vi','zh-Hans','zh-Hant']
HOLD_POSITIONS={505,511,513,514,515,523}
PH=re.compile(r'\{[^{}]+\}')
TAG=re.compile(r'<[^>]+>')
NUM=re.compile(r'(?<![\w])\d+(?:[.,]\d+)?(?![\w])')
def fail(m): raise SystemExit('FAIL: '+m)
def need(v,m):
    if not v: fail(m)
def sha(x):
    if isinstance(x,str): x=x.encode()
    return hashlib.sha256(x).hexdigest()
def canon(x): return json.dumps(x,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode()
def j(p): return json.loads(Path(p).read_text(encoding='utf-8'))
def jl(p): return [json.loads(x) for x in Path(p).read_text(encoding='utf-8').splitlines() if x.strip()]
# Candidate-free packet and exact review pin first.
subprocess.run(['python3',str(INPUT/'verify_input.py')],check=True,stdout=subprocess.DEVNULL)
im=j(INPUT/'manifest.json')
need((im['head'],im['tree'],im['window'])==(HEAD,TREE,'W505-W524'),'candidate-free pin')
input_cells=jl(INPUT/'current-target-cells.jsonl')
input_by={(x['sourceId'],x['locale']):x for x in input_cells}
ledger=jl(HERE/'primary-ledger.jsonl')
proposals=jl(HERE/'primary-proposals.jsonl')
holds=jl(HERE/'primary-holds.jsonl')
need(len(ledger)==240 and len({(x['sourceId'],x['locale']) for x in ledger})==240,'primary ledger coverage')
need({(x['sourceId'],x['locale']) for x in ledger}==set(input_by),'primary/input cell mapping')
counts=collections.Counter(x['disposition'] for x in ledger)
need(counts=={'accept-current':147,'correction':6,'refinement':15,'hold':72},'primary disposition counts')
need(len(proposals)==21 and len(holds)==72,'proposal/hold counts')
pmap={(x['sourceId'],x['locale']):x for x in proposals}
hmap={(x['sourceId'],x['locale']):x for x in holds}
need(len(pmap)==len(proposals) and len(hmap)==len(holds),'duplicate proposal or hold')
need(set(pmap)=={(x['sourceId'],x['locale']) for x in ledger if x['disposition'] in ('correction','refinement')},'proposal linkage')
need(set(hmap)=={(x['sourceId'],x['locale']) for x in ledger if x['disposition']=='hold'},'hold linkage')
for r in ledger:
    k=(r['sourceId'],r['locale']); c=input_by[k]
    for f in ('window','position','catalogZeroBasedIndex','catalogOneBasedPosition','sourceId','sourceSha256','locale','currentTargetSha256','callerContextSha256','callerRefs'):
        if f in ('window','position','catalogOneBasedPosition'): continue
        if f=='catalogZeroBasedIndex' and r[f]!=c['catalogZeroBasedIndex']: fail('selection index mismatch '+str(k))
        if f in ('sourceId','sourceSha256','locale','currentTargetSha256','callerContextSha256','callerRefs') and r[f]!=c[f]: fail('input linkage mismatch '+str(k)+' '+f)
    need(r['nativeSpeakerApproval'] is False,'native speaker approval claimed')
    need(collections.Counter(r['placeholderChecks']['source'])==collections.Counter(c['sourcePlaceholderTokens']),'source placeholder evidence linkage')
    need(r['placeholderChecks']['preserved'] is True and c['placeholderMultisetMatches'],'current placeholder mismatch')
    need(r['markupChecks']['preserved'] is True and c['markupMatches'],'current markup mismatch')
    need(r['numericChecks']['preserved'] is True and c['numericTokensPreserved'],'current numeric mismatch')
    need(r['protectedLiteralChecks']['preserved'] is True and c['protectedLiteralsPreserved'],'current protected-literal mismatch')
    if r['disposition']=='hold':
        need(r['position'] in HOLD_POSITIONS,'unexpected hold position')
        need(r.get('callerContextAvailable') is False,'hold incorrectly has caller')
        need(r['sourceId'] in {x['sourceId'] for x in jl(INPUT/'source-inventory-selection.jsonl') if x['catalogZeroBasedIndex'] in HOLD_POSITIONS},'hold source position mismatch')
        need(not any(x in r for x in ('source','currentTarget','proposedTarget','selectedTarget')),'hold contains source or translation text')
        need(bool(r.get('callerlessReason')),'hold lacks concise reason')
        continue
    need(r['source']==c['source'],'review source mismatch')
    need(r['currentTarget']==c['currentTarget'],'review current target mismatch')
    need(sha(r['currentTarget'])==c['currentTargetSha256'],'current target hash mismatch')
    if r['disposition']=='accept-current':
        need(r.get('proposedTarget') is None and r.get('reviewedContext'),'accept row shape')
    else:
        p=pmap[k]
        for f in ('currentTarget','currentTargetSha256','proposedTarget','proposedTargetSha256','disposition','rationale','callerContextSha256'):
            need(p[f]==r.get(f),'proposal differs from ledger '+f)
        target=r['proposedTarget']
        need(sha(target)==r['proposedTargetSha256'],'proposal hash mismatch')
        need(collections.Counter(PH.findall(c['source']))==collections.Counter(PH.findall(target)),'proposal placeholder mismatch '+str(k))
        need(collections.Counter(TAG.findall(c['source']))==collections.Counter(TAG.findall(target)),'proposal markup mismatch '+str(k))
        need(collections.Counter(NUM.findall(c['source']))==collections.Counter(NUM.findall(target)),'proposal numeric mismatch '+str(k))
        need(all(t in target for t in c['sourceProtectedLiterals']),'proposal protected literal mismatch '+str(k))
        need(all(r['proposalTokenChecks'].values()),'proposal token assertion mismatch')
summary=j(HERE/'summary.json')
need(summary['head']==HEAD and summary['tree']==TREE and summary['cellCount']==240,'summary pin/count')
need(summary['dispositions']==dict(counts) and summary['proposedCellCount']==21 and summary['newHolds']==72,'summary disposition mismatch')
need(summary['priorSelectedSourceCount']==120 and summary['priorHoldCellCount']==468 and summary['priorHoldChangedCells']==0,'prior lineage summary mismatch')
need(summary['nativeSpeakerApproval'] is False and summary['browserReviewClaimed'] is False,'unsupported review claim')
need(j(HERE/'provenance.json')['candidateFreeInputManifestSha256']==sha((INPUT/'manifest.json').read_bytes()),'provenance input manifest hash')
# Verify primary directory checksums, covering all files except checksum list.
expected={}
for raw in (HERE/'SHA256SUMS.txt').read_text().splitlines():
    h,n=raw.split('  ',1); expected[n]=h
actual={x.name for x in HERE.iterdir() if x.is_file() and x.name!='SHA256SUMS.txt'}
need(set(expected)==actual,'primary checksum coverage')
for name,h in expected.items(): need(sha((HERE/name).read_bytes())==h,'primary checksum mismatch '+name)
print(json.dumps({'result':'PASS','head':HEAD,'tree':TREE,'cells':len(ledger),'counts':dict(counts),'proposals':len(proposals),'holds':len(holds),'holdPositions':sorted(HOLD_POSITIONS)},sort_keys=True))

