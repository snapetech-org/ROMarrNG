#!/usr/bin/env python3
"""Portable integrity and linkage verifier for the blind ROMarrNG review packet."""
import collections, hashlib, json
from pathlib import Path
HERE=Path(__file__).resolve().parent
HEAD='e958b4fd0d9ddeac9333afc4c95da348b7f67cff'
TREE='402026ba276ec4603d86d659766af836d839de55'
LOCALES=['ar','de','es','fr','hi','id','ja','ko','pt-BR','vi','zh-Hans','zh-Hant']
def fail(msg): raise SystemExit('FAIL: '+msg)
def need(ok,msg):
    if not ok: fail(msg)
def sha(value):
    if isinstance(value,str): value=value.encode('utf-8')
    return hashlib.sha256(value).hexdigest()
def canon(obj): return json.dumps(obj,ensure_ascii=False,sort_keys=True,separators=(',',':')).encode('utf-8')
def read_json(name): return json.loads((HERE/name).read_text(encoding='utf-8'))
def read_jsonl(name): return [json.loads(x) for x in (HERE/name).read_text(encoding='utf-8').splitlines() if x.strip()]

# Checksum list must cover all packet files except itself, with safe relative names.
checks={}
for line in (HERE/'SHA256SUMS.txt').read_text(encoding='utf-8').splitlines():
    digest,name=line.split('  ',1)
    p=Path(name)
    need(name not in checks,'duplicate checksum path: '+name)
    need(not p.is_absolute() and '..' not in p.parts,'unsafe checksum path: '+name)
    need((HERE/p).is_file(),'missing checksum file: '+name)
    need(sha((HERE/p).read_bytes())==digest,'checksum mismatch: '+name)
    checks[name]=digest
actual={p.name for p in HERE.iterdir() if p.is_file() and p.name!='SHA256SUMS.txt'}
need(set(checks)==actual,'checksum file coverage mismatch')

packet=read_json('review_packet.json')
need(packet['head']==HEAD and packet['tree']==TREE and packet['window']=='W505-W524','pin/window mismatch')
need(packet['pullRequest']==70 and packet['repository']=='snapetech-org/ROMarrNG','PR/repository mismatch')
need(packet['sourceCount']==20 and packet['cellCount']==240 and packet['locales']==LOCALES,'scope mismatch')
need(packet['inputWasCandidateFree'] is True and packet['primaryReviewPacketRead'] is False,'blind-input attestation mismatch')
need(packet['nativeSpeakerReview']=='not performed' and packet['browserReview']=='not performed','review-limit statement missing')

sources=read_jsonl('review-sources.jsonl')
cells=read_jsonl('review-cells.jsonl')
need(len(sources)==20 and len(cells)==240,'source/cell count mismatch')
need([s['catalogZeroBasedIndex'] for s in sources]==list(range(505,525)),'source order mismatch')
sby={s['sourceId']:s for s in sources}
need(len(sby)==20,'duplicate source IDs')
need(len({(c['sourceId'],c['locale']) for c in cells})==240,'duplicate source/locale cells')
need(set((c['sourceId'],c['locale']) for c in cells)=={(s['sourceId'],l) for s in sources for l in LOCALES},'coverage mismatch')

for s in sources:
    need(len(s['sourceSha256'])==64 and len(s['callerContextSha256'])==64,'bad source/context hash')
    if s['callerless']:
        allowed={'catalogZeroBasedIndex','catalogOneBasedPosition','position','sourceId','sourceSha256','callerContextSha256','callerless','activeSourceRank','activeSourceRegistry','registryLocations','callerCount','textFreeHoldCode'}
        need(set(s)==allowed,'callerless source record contains text or unexpected fields')
        need(s['callerCount']==0 and s['textFreeHoldCode']=='CALLERLESS_SOURCE','callerless source hold marker mismatch')
    else:
        context=s['callerContext']
        need(context['callerless'] is False and context['sourceId']==s['sourceId'],'caller context/source mismatch')
        need(context['source']==s['source'] and sha(context['source'])==s['sourceSha256'],'source text/hash mismatch')
        need(context['contextSha256']==s['callerContextSha256'],'caller context hash mismatch')
        base={k:v for k,v in context.items() if k!='contextSha256'}
        need(sha(canon(base))==context['contextSha256'],'caller context content hash mismatch')
        need(len(context['callers'])==s['callerCount'] and s['callerCount']>0,'caller evidence count mismatch')
        need(all(x.get('path') and x.get('line') and x.get('lineText') for x in context['callers']),'incomplete caller evidence')

counts=collections.Counter()
for c in cells:
    s=sby[c['sourceId']]
    need(c['catalogZeroBasedIndex']==s['catalogZeroBasedIndex'],'cell position mismatch')
    need(c['sourceSha256']==s['sourceSha256'] and c['callerContextSha256']==s['callerContextSha256'],'cell linkage hash mismatch')
    need(c['locale'] in LOCALES and len(c['currentTargetSha256'])==64,'cell locale/hash mismatch')
    counts[c['disposition']]+=1
    if s['callerless']:
        allowed={'catalogZeroBasedIndex','sourceId','sourceSha256','callerContextSha256','locale','currentTargetSha256','callerless','disposition','proposedTarget','proposedTargetSha256','rationale','rationaleCode','confidence'}
        need(set(c)==allowed,'callerless hold contains source/target text or unexpected fields')
        need(c['callerless'] is True and c['disposition']=='hold','callerless cell is not held')
        need(c['proposedTarget'] is None and c['proposedTargetSha256'] is None and c['rationale'] is None,'callerless hold contains proposal/rationale text')
        need(c['rationaleCode']=='CALLERLESS_SOURCE_NO_PRODUCTION_CALLER' and c['confidence']=='high','callerless hold marker mismatch')
    else:
        need(c['callerless'] is False and 'currentTarget' in c and isinstance(c['currentTarget'],str),'reviewable cell lacks current target')
        need(sha(c['currentTarget'])==c['currentTargetSha256'],'current-target hash mismatch')
        need(isinstance(c['proposedTarget'],str) and c['proposedTarget'],'proposal missing')
        need(sha(c['proposedTarget'])==c['proposedTargetSha256'],'proposal hash mismatch')
        need(isinstance(c['rationale'],str) and c['rationale'] and c['confidence'] in ('high','moderate','low'),'rationale/confidence missing')
        if c['disposition']=='accept_current':
            need(c['proposedTarget']==c['currentTarget'],'accepted target differs from current')
        elif c['disposition']=='revise':
            need(c['proposedTarget']!=c['currentTarget'],'revision did not change target')
        else: fail('unexpected disposition: '+str(c['disposition']))
need(counts=={'accept_current':157,'revise':11,'hold':72},'disposition counts mismatch: '+str(dict(counts)))
need(packet['dispositions']==dict(counts),'manifest disposition counts mismatch')
need(packet['revisionCellCount']==11 and packet['callerlessHoldCellCount']==72,'manifest review counts mismatch')
print(json.dumps({'result':'PASS','head':HEAD,'tree':TREE,'sources':len(sources),'cells':len(cells),'dispositions':dict(counts),'locales':len(LOCALES),'callerlessSourceCount':sum(s['callerless'] for s in sources)},sort_keys=True))
